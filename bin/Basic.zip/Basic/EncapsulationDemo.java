package Basic;

/**
 * 
 * @author ragigupt
 * 1. Encapsulation is the process of binding or wrapping of data members and method into a single unit.
 * 2. Or restricting access to any members of an object.
 */
/*
 * How we can achieve Encapsulation ?
 * Declare the variable of class as private.
 * Provide public getter and setter method to view & modify the variable value.
 */
public class EncapsulationDemo {

}
